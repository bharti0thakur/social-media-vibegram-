import 'package:flutter/material.dart';
import 'post_detail_screen.dart';
class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    // Scaffold needs a GlobalKey to open the drawer from a custom button
    final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();

    return Scaffold(
      key: _scaffoldKey,
      backgroundColor: Colors.white,
      // --- THE DRAWER (3 lines menu content) ---
      endDrawer: Drawer(
        child: ListView(
          children: [
            const DrawerHeader(child: Text("Settings", style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold))),
            ListTile(leading: const Icon(Icons.settings), title: const Text("Settings and Privacy"), onTap: () {}),
            ListTile(leading: const Icon(Icons.history), title: const Text("Your Activity"), onTap: () {}),
            ListTile(leading: const Icon(Icons.qr_code), title: const Text("QR Code"), onTap: () {}),
          ],
        ),
      ),
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        title: const Text("flutter_dev", style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold)),
        actions: [
          IconButton(
            icon: const Icon(Icons.menu, color: Colors.black),
            onPressed: () => _scaffoldKey.currentState!.openEndDrawer(), // Opens the drawer
          )
        ],
      ),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Stats Section
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Row(
              children: [
                const CircleAvatar(radius: 40, backgroundColor: Colors.grey, backgroundImage: NetworkImage("https://i.pravatar.cc/150?img=3")),
                Expanded(
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      _buildStat("12", "Posts"),
                      _buildStat("1.5k", "Followers"),
                      _buildStat("300", "Following"),
                    ],
                  ),
                )
              ],
            ),
          ),
          // Bio Section
          const Padding(
            padding: EdgeInsets.symmetric(horizontal: 16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text("Flutter Developer", style: TextStyle(fontWeight: FontWeight.bold)),
                Text("Learning everyday 🚀"),
              ],
            ),
          ),
          // Buttons Section
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Row(
              children: [
                Expanded(child: OutlinedButton(onPressed: () {}, child: const Text("Edit Profile"))),
                const SizedBox(width: 10),
                Expanded(child: OutlinedButton(onPressed: () {}, child: const Text("Share Profile"))),
              ],
            ),
          ),
          const Divider(),
          const Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              Icon(Icons.grid_on),
              Icon(Icons.video_collection_outlined),
              Icon(Icons.person_pin_outlined),
            ],
          ),
          const SizedBox(height: 10),
          // --- GRID OF IMAGES WITH NAVIGATION ---
          Expanded(
            child: GridView.builder(
              itemCount: 12,
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 3, crossAxisSpacing: 1, mainAxisSpacing: 1),
              itemBuilder: (context, index) {
                String imageUrl = "https://picsum.photos/500?random=$index";
                return GestureDetector(
                  onTap: () {
                    // Navigate to the post detail page
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => PostDetailScreen(imageUrl: imageUrl),
                      ),
                    );
                  },
                  child: Image.network(imageUrl, fit: BoxFit.cover),
                );
              },
            ),
          )
        ],
      ),
    );
  }
  Column _buildStat(String number, String label) {
    return Column(
      children: [
        Text(number, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
        Text(label),
      ],
    );
  }
}